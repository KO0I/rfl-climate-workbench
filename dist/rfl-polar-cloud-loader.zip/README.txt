RFL polar cloud loader v1

Keep polar-clouds.js and polar-flow.js together. Open polar-cloud-format.html for the encoding and RFL shader integration example.
Generate a JSON pack in Planetary Climate Workbench > Polar storms > Cloud layers for RFL.
The loader must be connected to the gas renderer; the JSON is not automatically imported by existing RFL releases.
