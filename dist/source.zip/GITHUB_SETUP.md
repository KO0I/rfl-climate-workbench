# Publish the Workbench and include it in Chipchirp

Prepared for `KO0I/KO0I.github.io` and `https://chipchirp.digital` on September 17,
2026. The website's public repository was inspected: its default branch is
`master`, its Jekyll `baseurl` is empty, and it has a root `Gemfile`, `_config.yml`,
and `tools.md`. No `.github/workflows` directory was present at inspection.

The proposed new public repository is `KO0I/planetary-climate-workbench`, with
branch `main`. Substitute another name consistently if you prefer one.

The resulting website address will be:

**https://chipchirp.digital/planetary-climate-workbench/**

This is a deployment plan, not a currently published address. These instructions
do not change the existing hosted Workbench.

## 1. Extract and create the public repository

Extract the ZIP. The folder containing this guide is the new repository root;
it already contains both the source and the complete `dist/` app.

Use Bash, Git Bash, or a WSL terminal. Git and the GitHub CLI must be installed.
From that extracted folder:

```sh
git init -b main
git add .
git commit -m "Initial Planetary Climate Workbench release"
gh auth login
gh repo create KO0I/planetary-climate-workbench --public --source=. --remote=origin --push
```

The `gh repo create` command creates and publishes the public repository.
If you already authenticated with GitHub CLI, skip `gh auth login`. If the
repository name already exists, use that repository's intended workflow rather
than rerunning its creation. [GitHub CLI documentation](https://cli.github.com/manual/gh_repo_create).

Without GitHub CLI: create an **empty public repository** on GitHub named
`planetary-climate-workbench`; leave the README, license and gitignore initialization
options unchecked. After the first three commands above, run:

```sh
git remote add origin https://github.com/KO0I/planetary-climate-workbench.git
git push -u origin main
```

Use your normal Git credential manager or SSH configuration when prompted.
There are no repository credentials in this download.
[GitHub's repository-creation instructions](https://docs.github.com/en/repositories/creating-and-managing-repositories/creating-a-new-repository).

## 2. Add the submodule to the website

In your existing local checkout of **the website repository**, start with a clean
working tree and run:

```sh
git switch master
git pull --ff-only
git submodule add -b main https://github.com/KO0I/planetary-climate-workbench.git _workbenches/planetary-climate-workbench
```

If you do not have that checkout, first clone it into a separate folder:

```sh
git clone --recurse-submodules https://github.com/KO0I/KO0I.github.io.git
cd KO0I.github.io
```

Then run the submodule command. Use the public HTTPS URL in `.gitmodules`.
GitHub documents support for public HTTPS submodules in Pages builds.
[GitHub Pages submodules](https://docs.github.com/en/pages/getting-started-with-github-pages/using-submodules-with-github-pages).

The `_workbenches` prefix keeps the source checkout out of Jekyll's normal output.
Do **not** add `_workbenches` to `_config.yml`'s `include` list. The workflow will
copy only the app's `dist/` contents after Jekyll has finished.
[Jekyll configuration](https://jekyllrb.com/docs/configuration/options/).

## 3. Install the website deployment workflow

Still in the website checkout:

```sh
mkdir -p .github/workflows
cp _workbenches/planetary-climate-workbench/integration/chipchirp/pages.yml .github/workflows/pages.yml
```

The supplied file is a complete workflow for the website's `master` branch:

1. Check out the website and its pinned submodule revisions.
2. Set up Ruby and install the website's existing Gemfile dependencies.
3. Build the existing Jekyll website into `_site/`.
4. Copy the Workbench's `dist/` contents into `_site/planetary-climate-workbench/`.
5. Upload and deploy that **whole `_site/` directory**.

It uses your existing Jekyll configuration, theme and plugins. It does not rebuild
the numerical engines. If another Pages workflow has appeared since inspection,
merge the submodule checkout and copy step into that workflow instead of running
two competing deployment workflows.
[GitHub Pages workflow documentation](https://docs.github.com/en/pages/getting-started-with-github-pages/using-custom-workflows-with-github-pages).

The inspected `Gemfile` includes `jekyll-feed` and `jekyll-mermaid`, but
`Gemfile.lock` did not yet include them. The supplied install step permits Bundler
to reconcile that mismatch on the runner. When convenient, run `bundle install`
locally in the website checkout and commit the updated `Gemfile.lock` too.
Ruby setup uses version 3.3 and the repository's Bundler lockfile version.
[Ruby setup documentation](https://github.com/ruby/setup-ruby).

## 4. Connect the existing Tools link

In your website's `tools.md`, replace:

```markdown
[Planetary Climate Lab]()
```

with:

```markdown
[Planetary Climate Workbench]({{ '/planetary-climate-workbench/' | relative_url }})
```

Keep the surrounding heading and colored symbol if desired. This link opens the
app with its own Chipchirp-matched interface; its assets resolve relative to its
subdirectory.

To add it directly to the top navigation instead, add one item beneath
`menu-settings` → `menu-items` in `_data/settings.yml`:

```yaml
    - title: 'Climate Workbench'
      url: '/planetary-climate-workbench/'
```

This navigation item is optional; the existing Tools entry is sufficient.

## 5. Enable Actions publishing and push the website

On GitHub, open **KO0I/KO0I.github.io → Settings → Pages**. Under **Build and
deployment**, set **Source** to **GitHub Actions**. Keep the existing custom
domain `chipchirp.digital` and its DNS settings.

Commit from the website checkout:

```sh
git add .gitmodules _workbenches/planetary-climate-workbench .github/workflows/pages.yml tools.md
git commit -m "Publish Planetary Climate Workbench from its submodule"
git push origin master
```

If you changed `_data/settings.yml` or `Gemfile.lock`, stage those files before
committing as well. In the website repository's **Actions** tab, wait for
**Deploy Chipchirp and Planetary Climate Workbench** to succeed. If the workflow
ran before you changed the Pages publishing source, rerun it with **Run workflow**.

Then open `https://chipchirp.digital/planetary-climate-workbench/` and try a short
rocky-climate run and a short MagIC run. The actual GitHub deployment has not been
executed from this export; its first run also verifies your site's full Jekyll build.

## 6. Publish later Workbench updates

First edit, commit and push in the Workbench's own repository. HTML/CSS/JavaScript
edits in `dist/` need no build. C/Fortran edits require the corresponding rebuilt
engine files to be committed too.

Then, from the website checkout:

```sh
git submodule update --remote --checkout _workbenches/planetary-climate-workbench
git add _workbenches/planetary-climate-workbench
git commit -m "Update Planetary Climate Workbench"
git push origin master
```

The website pins a specific submodule commit. Pushing to the Workbench alone
does **not** update the website. The workflow deliberately uses that recorded
commit rather than silently fetching the latest `main` on every deployment.
`-b main` tells `git submodule update --remote` which branch to follow.
[Git submodule documentation](https://git-scm.com/book/en/v2/Git-Tools-Submodules).

For an existing website clone with an empty submodule directory:

```sh
git submodule update --init --recursive
```

## Local preview of the combined website

With your website's Ruby dependencies installed, run from its checkout:

```sh
bundle exec jekyll build --destination _site
mkdir -p _site/planetary-climate-workbench
cp -a _workbenches/planetary-climate-workbench/dist/. _site/planetary-climate-workbench/
python3 -m http.server 8000 --directory _site
```

Visit <http://localhost:8000/planetary-climate-workbench/>. Rebuild and recopy after
changes; this command does not watch files. Jekyll rebuilds can remove the copied
app folder, which is why the copy always follows the Jekyll build.

## If something fails

- **The website builds but the app returns 404:** confirm the workflow copied
  `dist/.` into `_site/planetary-climate-workbench/` before uploading `_site/`.
- **Empty submodule:** use recursive checkout in Actions, or the initialization
  command above locally. Keep the submodule repository public and its URL HTTPS.
- **Gemfile/lockfile mismatch:** run `bundle install` and commit `Gemfile.lock`;
  the provided workflow already allows resolving the missing plugin entries.
- **Wasm/data downloads fail:** copy the entire `dist/` directory, including
  `engine.data`, all three `.wasm` engines, workers and fonts.
- **Changes do not appear:** push the Workbench commit, then commit the updated
  submodule pointer in the website and let its deployment finish.

No separate Pages site is required for the Workbench repository. Your website's
existing Pages deployment serves both the blog and the app.
