# Planetary Climate Workbench

The **Gas giants · MagIC** tab runs MagIC 6.3's actual serial double-precision
Fortran convection solver in a separate browser worker. It provides bounded
Rayleigh/Ekman/Prandtl controls, density stratification, shell thickness, initial
entropy amplitude, and 128 × 64 × 17 or 192 × 96 × 25 computational grids.
The longitude/latitude map is 768 × 384 pixels and the globe is 512 × 512.
The original rocky terrain, ExoPlaSim, planet-tool and atmosphere views remain
available through the navigation above the controls.

MagIC outputs drive a rotatable globe and a 2:1 longitude/latitude map. Choose
entropy anomaly, eastward or radial velocity, flow speed, or artistic entropy
colors; inspect each radial shell, pause/resume, replay sampled frames, and export
the current shell or native MagIC namelist. The color palettes are appearance
choices, not planet calibrations. No condensation, radiation, visible cloud
microphysics, or magnetic field is included. Short cold-start runs are spin-up.
See `model/magic/BROWSER.md` for provenance, equations, units and build details.

Experimental T21L10 port of the ExoPlaSim Fortran model. Runs a single CPU instance
in a browser Web Worker. No remote compute service, Python interpreter, MPI,
WebGPU, or CUDA is used. The HTML interface samples the model's actual grid arrays.

Upstream source: https://github.com/alphaparrot/ExoPlaSim
Pinned upstream commit: `bb46316ca917e907b129b0d764b11a9119e0088e`
Downloaded 2026-09-10. The original model sources and T21 boundary data are in `model/`.

## Planet and atmosphere explorer

Eight planet presets span icy bodies, cool/temperate/warm rocky experiments,
Venus-like greenhouse worlds, boiling steam worlds, and molten silicate worlds.
Nineteen atmosphere options control an explicit horizon / upper atmosphere /
edge-of-space color palette. The vertical preview, horizontal gradient, swatches
and JSON export share one palette definition in `dist/world-catalog.js`.

The nitrogen-rich / Earth-like palette uses the exact daytime RGB anchors from
RFL's `raycaster_planet.c`, `apply_atmosphere()`:

| RFL color | RGB | Hex | Gradient position |
| --- | --- | --- | --- |
| `pale` (dense air) | 210, 238, 255 | `#D2EEFF` | 0% |
| `cyan` (limb) | 76, 184, 242 | `#4CB8F2` | 30% |
| `electric_blue` | 20, 92, 220 | `#145CDC` | 58% |
| `deep_blue` (outer edge) | 7, 27, 96 | `#071B60` | 82% |
| `deep_space_color()` zenith base | 4, 7, 19 | `#040713` | 100% |

Source: `rfl_PLAYTEST.zip`, Library version 15, SHA-256
`27853ecc2d70f5f1590620ec1af98e2df322cce8342ffc5ca75f7018d0de4f68`.
The displayed colors match the game's constants. Gradient positions are an
illustrative layout, not altitude, density or a port of RFL's ray integration.
RFL blends its colors using optical depth, viewing angle and illumination, with
additional violet night and warm terminator colors. Its separate surface sky
also includes star-dependent tinting. The Lab retains its existing daytime
upper-atmosphere palette preview; it does not simulate those dynamic effects.
JSON exports include the colors, labels, positions, space color and source.

Other palettes are authored artistic scattering approximations, not measured
spectra, ExoPlaSim outputs, or verified Elite Dangerous color mappings. The user-provided
reference is https://elite-dangerous.fandom.com/wiki/Atmosphere; it blocked
retrieval during this update. No wiki prose or image assets were copied.

Randomize now always selects a world with a field model and starts its calculation.
It preserves the ExoPlaSim run length. Cool/temperate/warm rocky worlds use the
existing Fortran worker; ice, volatile ice, Venus-like, steam and silicate worlds
use the separately labeled steady grey surface estimate in `dist/surface-model.js`.
The latter computes surface temperature and prescribed pressure (or a local
illustrative rock-vapor proxy), never fake wind, cloud or air-temperature fields.
Extreme exports identify their own model, equal-area grid, assumptions, parameters
and available fields; they contain no elapsed simulation time or Fortran namelists.

The class weights are cold 15%, temperate 35%, warm 15%, ice 8%, volatile 8%,
Venus-like 8%, steam 6%, silicate 5%. These are authored exploration priors, not
observed planet frequencies. Repeating a class is permitted. Conditional choices
link atmosphere, sunlight, pressure and albedo, with bounded rejection screening
and checked fallback references. In rocky climates, CO₂ bounds depend on sunlight
and rotation favors near-daily periods. In extreme estimates, temperature and
approximate condensation screens reject inconsistent regimes. See
`dist/surface-model.html` for all equations, assumptions, priors and references.

The new surface model is deliberately limited: smooth spherical surfaces,
prescribed grey opacity and redistribution, no terrain, circulation, spectral
radiation, atmospheric escape, gas-mixture chemistry or climate evolution.
Temperature colors automatically span each extreme world's range. Atmospheric
pressure is uniform except for the silicate vapor proxy. Appearance palettes remain
independent of field physics. Unsupported manual gas combinations remain available
as appearance-only choices and are labeled in the selector.

During ExoPlaSim runs, including pauses, world and terrain selectors and randomization
are disabled; Reset permits another choice. Resolution stays available and resets
the simulation when changed. Changing worlds or inputs clears old output. Extreme
surface estimates have no run length, pause or simulated elapsed time.

## Supported experiment

- RFL terrestrial geography: T21 (64 × 32), with 10 vertical levels and Gaussian
  latitudes. Low/High res selects display detail only.
- Stellar flux 800–1800 W/m²; CO₂ 10–2000 ppm; rotation 0.5–10 Earth days.
- Thirty-minute physical timesteps; seasonal
  sunlight; initial atmosphere from
  the model's defaults. The cold start is **not** an equilibrated climate.
- Surface air temperature, total column cloud fraction, lowest-level winds,
  and surface pressure; JSON export retains the original Gaussian coordinates.
- Pause/resume while the page stays open. Reset starts a new model instance.
- No restart import, long-term persistence, Python API, arbitrary namelists,
  alternate planet geometries, or scientific validation beyond the checks
  recorded in `VALIDATION.md`. It is not an Orbital/ringworld solver.

## Terrestrial planet tool, cubemap and playback

The **Quick heightmap / Terrain Solver** tabs above the height overview select
the terrain generator. Quick keeps the existing RFL noise sampler. Terrain Solver
runs the original C99 algorithm-2 core from `RFL_Cubemap_Terrain_C99.zip`, compiled
to WebAssembly, on a separate worker. `model/terrain-solver/src/cubeterrain.c`,
`include/cubeterrain.h`, and `include/ct_knobs.def` are unchanged copies; the small
`src/browser.c` file supplies the browser ABI. The original package's README and
reference notes are retained there for algorithm provenance; its optional CLI,
streaming cache and sample chunk files are not part of this browser integration.

The top-level Continents & relief tab exposes Balanced, Archipelago, Alpine and Regional presets;
32/64/128 macro cells per cube-face edge; continent frequency, liquid threshold,
noise blend, coastline warp, noise relief, fine roughness, macro slope and regional
variation. Other parameters retain the selected C preset's values. Editing knobs
requires **Generate terrain**; selecting the solver tab or randomizing generates
automatically. A completed world is reused when returning to its tab or changing
display resolution. One seed is shared with Quick; each generator retains its
other controls. Terrain edits clear completed climate fields and replay, and are
locked during a live or paused climate run.

The solver builds one connected six-face graph, fits lake levels and macro slopes,
then samples it for the 64 × 32 climate grid, both display resolutions, and both
2:1 longitude/latitude height overviews. Generation loads through the page's authenticated session;
workers perform no downloads. Only the result arrays survive worker termination.
The Wasm starts with 16 MiB and is capped at 128 MiB. Cancel, timeout and failure
preserve the last displayed terrain and block a new climate run until the selected
configuration succeeds. There is no silent fallback to Quick. Macro slope bounds
do not constrain the added fine detail. The generator is procedural terrain, not
a physical erosion or hydrology simulation.

Both generators supply the same land-mask/elevation interface to ExoPlaSim.
Solver heights retain metres and the sea-level datum; the exposed surface is
`max(0, water_m)` over water and `max(0, height_m)` over land. Thus elevated lakes
remain raised surfaces, while sea-floor depth does not become atmospheric
orography. Solver water, sand and remaining land use the existing editable
liquid/coast/land palette rows. JSON retains the actual generator, full effective
C configuration, generation digest, solve diagnostics, sea-floor/ground heights,
water levels and biome IDs alongside the physical boundary arrays. The simplified
extreme-world estimate continues to ignore terrain, as its UI and export state.

Rebuild the small terrain engine independently with an installed Emscripten:
`python3 scripts/build-terrain-solver.py` (or pass the path to `emcc`/`emcc.py`).
The bundled artifact was built with Emscripten 3.1.6 and LLVM 15. The Fortran engine
is unchanged. `scripts/test-terrain-solver.mjs` compares native C and browser Wasm
samples, checks all four presets and runs the actual worker without networking.

The Climate map, Planet tool and Upper atmosphere tabs share one world and run.
The terrestrial `hash3`, `vnoise`, `fbm`, `terrain_idx` and default 5 × 4 palette
are ported from RFL's `planet_tool.c`, retained under `model/rfl-planet-tool/`.
The noise port uses Float32 arithmetic and is compared directly with compiled C.
Stars, gas giants, orbitals, rings and city effects are outside this terrestrial
climate integration. Globe shading is a lightweight adapter, not a full port of
RFL's space renderer.

The selected generator's controls determine the model land mask
and orography. Before Fortran initialization, the worker removes the bundled
Earth-specific surface fields and supplies generated land/ocean boundaries,
geopotential (elevation × 9.80665), zonally symmetric starting temperatures,
and uniform land-property defaults. Colors are visual only and do not infer
physical albedo from RGB. Geography is locked during a run, including pauses;
Reset clears its recorded frames before terrain edits. Terrain is spectrally
smoothed inside the T21 solver; high-frequency or steep terrain and long runs are unvalidated.

The solver always uses the original T21 64 × 32 grid and 30-minute timestep.
Low res displays 64 × 32 terrain cells; High res displays 128 × 64 (four times
as many cells). High res samples the selected seeded terrain field more densely for
appearance, while only the original 64 × 32 terrain reaches the climate model.
One climate cloud cell controls a 2 × 2 group of High-res display cells.
The small detail variations in that group have the same mean coverage as the
original cell. They do not enter the physical solver or exported climate fields.

Terrain generation is the first setup section. Quick heightmap and Continents &
relief are sibling tabs containing their generator controls, with a shared seed
and Randomize terrain action. The latter tab runs the Terrain Solver. These
controls no longer sit in the Planet tool workspace tab, which contains the globe,
cloud controls and palette editor. Randomize world follows the terrain preview;
climate options and Run simulation follow the terrain setup section.

A 2:1 longitude/latitude terrain-height overview sits directly below the terrain
generation controls. It keeps the doubled latitude detail: 128 × 64 in Low res,
256 × 128 in High res. Longitude sampling increases to match, so each displayed
pixel spans the same angular increment in both axes. Its uniform latitude rows
run north to south, with longitude from west to east and 0° in the middle. These
are fresh height samples, not duplicated rows. The canvas preserves its intrinsic
aspect ratio as the page resizes. Square pixels are not equal-area cells on the
sphere. The overview updates with terrain controls and resolution, caches between
changes, and uses the elevation color scale independently of the selected climate
layer. The solver boundaries, globe/cubemap texture grids, and cloud grids keep
their existing sizes.

The T42 assets have been removed from the site. Both display options load the
same original engine, with a 64 MiB initial Wasm memory and an 8 MiB guarded
stack. The globe caches its two sphere depth arrays in packed Float32 arrays
(2 MiB total at High res); the High-res cloud detail arrays use about 41 KiB.
The globe and each cubemap face double from 256 × 256 to 512 × 512;
the shared longitude/latitude texture doubles from 1024 × 512 to 2048 × 1024.
High res still adds rendering work and image-buffer memory. It does not enlarge
the climate calculation. The page layout and globe orientation stay the same.
Changing resolution cancels any download or live/paused run and clears output
and replay before redrawing. A new simulation must be started explicitly.

The globe, longitude/latitude map and six cubemap faces use the same ground
and climate data. Clouds are a separate overlay. The cubemap is a projection, not an increase in climate
resolution or a replacement for ExoPlaSim's Gaussian spherical grid. Individual
faces can be viewed as square flat maps. Face directions agree along all edges
and corners; terrain and climate layers follow the same convention. Rendering
flat terrain around an RFL player and switching to the globe in space remains
an RFL game-renderer concern; this lab does not contain a player or flight mode.

The actual 5 × 4 palette sprite is enlarged for editing. Select a pixel by
touch/click or arrow keys, then change its color with the picker or a hex value.
A direct “Edit palette sprite” button sits below the globe. Open and save PNG,
uncompressed BMP, and opaque hex-color XPM2 / C XPM palettes; all twenty pixels
retain their top-down land/coast/liquid/cloud row order. The PNG decoder rejects
other dimensions and transparency. An expandable view retains all twenty
individual color inputs. Runtime terrain
uses cached palette indices; XPM is an interchange format, not a per-frame
parser or a claim of faster simulation. Scientific color scales bypass terrain,
cloud color and lighting so their legends remain meaningful. Field options
include both surface and air temperature, cloud cover, wind speed and pressure.
Wind arrows are shown in the longitude/latitude view.

The cloud-source button switches between the original RFL thresholded 3D-noise
mask and a hybrid mask controlled by the actual ExoPlaSim column cloud fraction.
Both use the existing RFL fBm noise. High-res hybrid detail redistributes coverage
within each four-cell display group while preserving its climate-cell mean;
zero coverage stays clear and full coverage stays opaque. Scientific cloud maps
and JSON exports always show the raw model fraction.

The globe draws the cloud layer on a separate sphere with a radius 1.14 times
the ground radius. Its own sphere intersection and normal make clouds extend
past the planet silhouette, with background visible through clear parts of the
shell. The radius is deliberately artistic, not a simulated cloud altitude.
Ground and cloud lookup coordinates rotate together. Noise drift follows the
displayed simulation time, so pause and replay are reproducible. Flat maps and
cubemap faces composite the same cloud mask over their surface projection.
This follows the larger-radius cloud-shell approach described by
[DaFluffyPotato](https://www.youtube.com/shorts/7g5Cj_1XPkM) and already present in
RFL's `render_planet()`; no new volumetric simulation is introduced.

Both views have controls for pausing/resuming the live solver, seeking,
playing recorded output, and returning to the latest frame. Replay retains at
most 481 snapshots at either display resolution (about 28 MB of field arrays),
thinning older samples during
long runs. Replay is a sequence of actual saved frames; speed is snapshots per
second, not uniform physical time. Reset and leaving the page clear the buffer.
Exports describe the displayed frame, terrain, palette, cloud source, display resolution, solver
resolution and actual coordinates. Every physical field retains 2,048 samples.

Extreme worlds retain their separate static 64 × 32 surface estimate,
independent of the selected display resolution. Their physical
fields ignore relief and land/liquid boundaries, and no wind, cloud or time
history is fabricated for them. Their terrain colors are appearance only.

## Build

Use the public `ghcr.io/r-wasm/flang-wasm:v21.1.8` compiler image, or extract its
`/opt/flang` and `/opt/emsdk` tools locally. Compiler source is pinned at
`e3da0a873ea32bca563c2cccdd4d7622b13cef50` in https://github.com/r-wasm/llvm-project.
Set `EM_CONFIG` to the toolchain's Emscripten configuration. Build the patched
Fortran runtime with `scripts/build-runtime.py` as documented in that script.
Then set `EXO_FORTRAN_RUNTIME` to the resulting `libFortranRuntime.a` and run:

```
python3 scripts/build-wasm.py /absolute/path/to/opt
```

To prepare the tools on Linux without installing system packages (requires Python 3.12+, Node.js, make, and a compatible C++ host runtime):

```
python3 scripts/fetch-toolchain.py /tmp/exoplasim-tools
python3 scripts/configure-tools.py /tmp/exoplasim-tools
python3 scripts/fetch-runtime.py /tmp/exoplasim-llvm
EM_CONFIG=/tmp/exoplasim-tools/emscripten.config python3 scripts/build-runtime.py /tmp/exoplasim-tools/opt /tmp/exoplasim-llvm /tmp/exoplasim-runtime
EM_CONFIG=/tmp/exoplasim-tools/emscripten.config EXO_FORTRAN_RUNTIME=/tmp/exoplasim-runtime/libFortranRuntime.a python3 scripts/build-wasm.py /tmp/exoplasim-tools/opt
```

The tool download is approximately 720 MiB; the browser downloads only the much
smaller compiled model and data. Runtime source is downloaded from its pinned
commit; the tools never install system packages. Tool extraction needs several GB
of temporary disk space.

Serve `dist/` with any static HTTP server. `engine.js`, `engine.wasm`, and
`engine.data` must be served beside the page. No installation occurs in the user's
browser. The compiler is used only when building the site.

The page downloads the worker scripts, compiled model and boundary data using its
same-origin session, checks the responses, and creates a classic Blob worker.
The binary buffers are transferred into that worker and supplied through
Emscripten's `wasmBinary` and `getPreloadedPackage` inputs. Computation remains in
the worker, which needs no further script imports or network access. This avoids
depending on a separate worker request context to authenticate protected assets.
Reset cancels pending downloads, terminates computation, and releases the Blob URL.
Loading/startup deadlines and error fallbacks prevent indefinite loading or an
unhelpful `undefined` error. Reopening the site may still be necessary if the page's
own session has expired; browsers must allow WebAssembly and Blob workers.

After building (or in the complete Site checkout), run `node --test scripts/test-engine.mjs`
with Node.js 24 or later for the loader regressions, real T21 runs, and one-day boundary/terrain cases. Both display selections
are checked to load the same engine. Run `node --test scripts/test-worlds.mjs`
for capability, generator and surface-estimate checks. Run
`node --test scripts/test-terrain.mjs scripts/test-resolution.mjs scripts/test-clouds.mjs`
for terrain/projection grids, resets, replay, exports, cloud coverage conservation,
cloud-shell pixel geometry and palette editing.
This uses a VM worker context and does not replace testing on a physical device.

## Port changes

The scripts preserve the original sources and generate adapted sources in `.build/`:

1. Split the original initialization and time-stepping loop into callable entry
   points. Preserve the upstream physics order. A Web Worker advances the model
   in short batches, allowing pause and responsive page controls.
2. Select upstream serial MPI, GUI, and ocean-coupling stubs. Correct their unused
   argument lists to satisfy WebAssembly's strict function signatures.
3. Repair two upstream `calini` calls which omitted the timestep argument; declare
   that argument real, matching `MPSTEP`. The native comparison applies the same fix.
4. Add missing Makefile dependencies for glacier and aerosol modules.
5. Adapt three Flang runtime ABI declarations where a Linux-hosted compiler's
   `int64_t` and `long` mapping differs from Wasm32. File inquiry uses the `EXIST`
   keyword, whose hash is fully representable in 32 bits. Resource counters are
   disabled; no climate field is passed through a diagnostic integer adapter.
6. Build the Fortran runtime with 64-bit descriptor element lengths and dimension
   indices, matching Flang's emitted descriptor layout while retaining 32-bit pointers.
7. Import the processor IDs and capture flag explicitly in `hurricaneini`; upstream
   accidentally reads uninitialized locals, which LLVM optimizes to a trap.
8. Disable random kick forcing (`KICK=0`) for reproducible compiler comparisons.
   Terrain and seasonal forcing still generate longitudinal variation.

The numerical model has not been rewritten in JavaScript. Climate convergence,
all atmospheric parameter combinations, and mobile performance are not certified.

## Licenses

ExoPlaSim: GPL-2.0 (`dist/LICENSE-ExoPlaSim.txt`). This browser port is distributed
under GPL-2.0. LLVM runtime: Apache-2.0 with LLVM exception; Emscripten: MIT/University
of Illinois; flang-wasm build tools: MIT. License texts are included in `dist/`.

## Saturn interior cutaway

The Saturn-like preset includes five appearance layers: stratospheric haze,
ammonia ice, ammonium hydrosulfide ice, water ice, and an artistic metallic
hydrogen center. The selector and layer buttons remove all overlying shells.
Remove/restore animates a widening section through the shell; section walls are
ray intersections with concentric volumes and clipping planes. Rotation, polar
views, opening, rings and zoom remain independent of the selected layer.

Each layer retains its color and material controls while switching layers.
Clouds offer jets, cells and filaments; the NH4SH deck defaults to a Cassini
PIA13405-inspired false-color appearance. Both prescribed polar polygons extend
through water clouds. This is a kinematic visual interpretation, not MagIC
output, a condensation model, or a claim about observed deep polygon coherence.
Layer thicknesses and the intervening hydrogen envelope are compressed. Actual
water clouds are not glass, and metallic hydrogen is not Saturn's central
heavy-element core; the interface explains those substitutions.

`dist/xpm-glass-optics.js` is reused unchanged from the user's XPM Workbench.
`dist/saturn-neutral-drone.xpm` was generated using its `makeDroneBXpm` with
65 × 65 × 65 slices, a 26-voxel glass radius, and the original 12-voxel mirror
core. The mood and shell colors are neutral, and floor colors are transparent.
The Saturn renderer reads the XPM sphere/core directives, preserving their radius
ratio; it uses the original Fresnel and dielectric tracing helpers, neutral tints,
absorption, scattering and dispersion conventions. Display sphere surfaces are
smooth analytic reconstructions of the XPM sphere, as in the original optics
renderer. XPM source is downloadable from the interpretation details.

The animation stops when its tab or document is hidden. Reduced-motion users get
paused clouds and immediate layer restoration/removal. The mobile Saturn viewer
precedes its material controls. No browser-only service or backend was added.

## Jupiter layers and glowing interior

Gas giants → Jupiter-like adds six appearance layers: stratospheric haze,
ammonia ice, ammonium hydrosulfide ice, water ice, molecular hydrogen and helium,
and an artistic metallic-hydrogen center. Cream/rust belts, an animated Great
Red Spot, and eight-around-one northern / five-around-one southern cyclone
clusters use a separate periodic kinematic texture model. The supplied cloud
reference determines layer order; depth spacing is exaggerated and the deep
envelope compressed. The interface links NASA's Jupiter structure/cloud summary
and distinguishes the artistic glass and mirror center from real planetary matter.

The water shell defaults to blue-green `#26b6b0`, refractive index 2.5 (the
slider maximum), and surface scatter 0.50 (the midpoint). Saturn's 12/26
mirror-core radius ratio is reused. A translucent hydrogen envelope preserves
visibility of the red-orange `#ff5318` internal emission. Emission energy above
display white is retained while being refracted through the glass, so absorption
and scattering do not extinguish the glow through early byte-buffer clipping.
Core glow color/intensity can be edited while viewing water, hydrogen or metal.
The center remains reflective. Jupiter starts without the broad Saturn rings.

Both objects share the existing cutaway geometry, remove/restore animation,
layer controls and XPM optics. Each keeps independent in-session appearances,
selected layer, camera, environment, animation and opening settings when changing
presets. Reset restores only the selected planet. The numerical MagIC and rocky
climate engines are unchanged.
